from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
from tkinter import *

bot = ChatBot("My Bot")

convo=[
    'hi',
    'hey,good to see you again',
    'hello',
    'hey there',
    'hello ASCA',
    'hi there!',
    'bye',
    'nice talking to you,bye!!',
    'ttly',
    'see you soon',
    'what is your name',
    'my is name is ASCA, created by Aman',
    'how are you?',
    'Im fine,Thank you',
    'where are you from',
    'Im from CYBER WORLD',
    'what do you eat',
    'i love eating chips and bytes',
    'what do you do these days',
    'these days internet never gets me bored',
    'who is your first love?',
    'his name is Python,i love his company',
    'Tell me a joke',
    'Did you hear the one about the mountain goats in the andes? It was "ba a a a a a d" ',
    'Tell me one joke',
    'What do you get when you cross a cheetah and a hamburger? Fast food.',
    'jokes',
    'What do you get when you cross an excited alien and a chicken? Eggs-cited eggs traterestrial',
    'can you make me laugh',
    'What do you get when you cross a murderer and frosted flakes? A cereal killer.',
    'crack a joke',
    'What do you get when you cross a country and an automobile? Carnation.',
    'Tell me a joke',
    'What do you get when you cross finals and a chicken? Eggs-ams.',
    'Tell me a joke',
    'What do you get when you cross a rabbit and a lawn sprinkler? Hare spray.',
    'Tell me a joke',
    'What do you get when you cross an alien and a chicken? Eggs-traterrestrial',
    'Tell me a joke',
    'What do you get when you cross music and an automobile? Cartune.',
    'what do you get when you cross a cat and a band?',
    'tell me some jokes',
    'what do you get when you cross a pig and a ninja?',
    'no',
    'pigjaa its pizzaaa lol',
    'Do know any jokes',
    'what do you get when you cross a crazy cow and a banned parrot?',
    'puzzles',
    'what do you get when you cross a cow and a lemon?',
    'give me a puzzle',
    'what do you get when you cross a bad cow and a canned hat?',
    'what is humour?',
    'An emotion associated with laughter.',

]

trainer = ListTrainer(bot)

# now training the bot with the trainer

trainer.train(convo)

#answer = bot.get_response("what is your name?")
#print(answer)

#print("talk to the bot")
#while True:
#    query=input()
#    if query=='exit':
#        break
#    answer=bot.get_response(query)
#    print("bot :",answer)
main = Tk()
main.geometry("500x650")
main.title("ASCA")
img=PhotoImage(file="ASCA.png")
photoL = Label(main, image=img)
photoL.pack(pady=5)

def ask_from_bot():
    query = textF.get()
    answer_from_bot = bot.get_response(query)
    msgs.insert(END, "YOU : " + query)
    print(type (answer_from_bot))
    msgs.insert(END, "ASCA :" + str(answer_from_bot))
    textF.delete(0, END)
    msgs.yview(END)
frame = Frame(main)
sc = Scrollbar(frame)
msgs = Listbox(frame, width=80,height=20, yscrollcommand=sc.set)
sc.pack(side=RIGHT, fill=Y)
msgs.pack(side=LEFT, fill=BOTH, pady=10)
frame.pack()
# creating text field
textF = Entry(main, font=("Verdana",20))
textF.pack(fill=X, pady=1)

btn = Button(main,text="Ask from ASCA", font=("Verdana",20), command=ask_from_bot)
btn.pack()
# creating an enter function
def enter_function(event):
    btn.invoke()

# going to bind main window with enter keys
main.bind('<Return>',enter_function)
main.mainloop()